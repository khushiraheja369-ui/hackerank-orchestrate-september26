# Buy or Wait? AI Financial Decision Agent

Submission for **HackerRank Orchestrate** (September 2026).

## Overview

An autonomous, multimodal AI financial decision agent that decides whether a user can safely afford a requested purchase or payment. The system evaluates cash positions across multiple currencies, accounts for confirmed income, pending debits, recurring commitments, and untrusted message/image evidence, and generates actionable, verified recommendations:
- `full_payment`
- `partial_payment`
- `installments`
- `wait`
- `not_recommended`

## Architecture & Guarantees

1. **Deterministic Financial Engine:**
   - Money arithmetic is computed using Python's `Decimal` with zero intermediate rounding/quantization.
   - 90-day daily balance simulation ensures $B(t) \ge \text{minimum\_balance\_to\_keep}$ for every day $t \in [0, 90]$.
   - Same-day deterministic netting of credits and debits.

2. **Multimodal Fact Extraction Boundary:**
   - AI/VLM models are strictly restricted to extracting document facts, receipts, and message evidence.
   - AI **never** makes financial decisions (affordability, safe amounts, ranking, or winning plans are 100% deterministic).

3. **Data-Driven Recurrence Detection:**
   - Detects monthly calendar anchors (intervals $\in [27, 32]$ days) and periodic day cadences ($\in \{7, 10, 14, 21\}$ days).
   - Distinguishes contractual commitments from one-time bulk outliers ($> 2.5\times$ median).
   - Dynamically accounts for verified rent increases, salary adjustments, and contract lifecycle changes.

4. **Independent Plan Verifier:**
   - Every candidate and winning plan undergoes an independent 90-day re-simulation and invariant pass before final selection.

## Directory Structure

```text
.
├── code/
│   ├── config.py                  # Schemas, currencies, token pricing
│   ├── data_loader.py             # Multimodal cache, CSV loaders, direct FX
│   ├── event_resolver.py          # Message facts, cancellations, payroll parsing
│   ├── financial_state.py         # Reconstructed financial profile
│   ├── recurrence_detector.py     # Data-driven cadence & outlier detection
│   ├── simulator.py               # 90-day Decimal balance simulator
│   ├── plan_ranker.py             # 6-tier lexicographical comparator
│   ├── spending_optimizer.py      # Flexible spending change optimizer
│   ├── plan_generator.py          # Candidate plan generation & evaluation
│   ├── verifier.py                # Independent verification & invariant pass
│   ├── explanation_generator.py   # Grounded natural-language explanation
│   ├── main.py                    # CLI entry point
│   └── test_*.py                  # Unit and regression test suites
├── dataset/                       # Provided challenge dataset
├── evaluation/
│   ├── usage_report.md            # Token counts, model calls, and pricing
│   ├── sample_benchmark_results.md# Benchmark across 25 public sample requests
│   ├── validation_report.md       # Invariant & 90-day re-simulation audit
│   └── high_risk_cases.md         # Audit of complex financial cases
├── output.csv                     # Final predictions (250 rows)
├── SPEC_AUDIT.md                  # Comprehensive rule & specification audit
├── requirements.txt               # Dependencies
└── README.md
```

## Setup & Running

### Requirements
- Python 3.9+ (tested on Python 3.14)
- Standard Library only (zero external mandatory dependencies)

### Run Full Evaluation
To evaluate all requests in `dataset/requests.csv` and generate `output.csv`:

```bash
python code/main.py --mode full --output output.csv
```

### Run Sample Benchmark
To run regression testing on `dataset/sample_requests.csv`:

```bash
python code/main.py --mode sample --output output_sample.csv
```

### Run Unit Tests
```bash
python code/test_event_resolver.py
python code/test_recurrence.py
python code/test_simulator.py
python code/test_plan_generator.py
```
